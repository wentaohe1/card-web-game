<?php
session_start();
$avatarSrc = isset($_SESSION["avatar"]) ? $_SESSION["avatar"] : (isset($_COOKIE["avatar"]) ? $_COOKIE["avatar"] : "default-avatar.png");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
    session_unset();
    session_destroy();
    setcookie("username", "", time() - 3600, "/");
    header("Location: index.php");
    exit();
}
unset($_SESSION['game_started']); // Reset the session when returning to index.php
$isRegistered = isset($_SESSION["username"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Home</title>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.querySelector('.dropdown-menu');

            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });

            document.addEventListener('click', function() {
                dropdown.classList.remove('show');
            });

            dropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        });
    </script>
    <style>
        .welcome-container {
            position: relative;
            margin-top: 50px; /* Pushes content below navbar */
            width: 1000px;
            height:500px;
            background-color: white;
            transform: scale(0.6);
            border-radius: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            justify-content: center;
            text-align: center;
        }
        .welcome-container h1{
            margin-top: 140px;
            font-size: 80px;
        }
        .btn {
            display: inline-block;
            cursor: pointer;
            width:320px;
            height: 100px;
            font-size: 28px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            border-radius:20px;
            background-color: blue;
            color: white;
            font-weight: bold;
        }
        .welcome-container p{
            font-size: 20px;
            font-weight: bold;
        }
        .welcome-container a{
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header>
        <?php
        $isRegistered = isset($_SESSION["username"]);
        ?>
        <!--navigation bar-->
        <nav class="navbar">
            <div class="navdiv">
                <div class="navdiv left">
                    <ul>
                        <li><a href="index.php" name="home" style="margin-left: -10px;">Home</a></li>
                    </ul>
                </div>
                <div class="navdiv right">
                    <ul>
                        <li><a href="pairs.php" name="memory">Play Pairs</a></li>
                        <?php if ($isRegistered): ?>
                            <li><a href="leaderboard.php">Leaderboard</a></li>
                            <li class="user-menu">
                            <img id="avatarImage" src="<?php echo htmlspecialchars($avatarSrc); ?>" alt="User Avatar">
                                <div class="dropdown-menu">
                                    <div class="dropdown-divider"></div>
                                    <form method="POST" action="" style="display: inline;">
                                        <button type="submit" name="logout" class="dropdown-item" style="border: none; background: none; cursor: pointer;">
                                            Log Out
                                        </button>
                                    </form>
                                </div>
                            </li>
                        <?php else: ?>
                            <li><a href="registration.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div id="main">
          <div class="welcome-container">
              <h1>Welcome to Pairs</h1>
              <?php if ($isRegistered): ?>
                <button class="btn" onclick="window.location.href='pairs.php';">Click here to play</button>
              <?php else: ?>
                <p>You're not using a registered session?<a href="registration.php"> Register now</a></p>         
              <?php endif; ?>
          </div>
    </div>
    
</body>
</html>