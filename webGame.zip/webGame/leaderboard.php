<?php
session_start();
$avatarSrc = isset($_SESSION["avatar"]) ? $_SESSION["avatar"] : (isset($_COOKIE["avatar"]) ? $_COOKIE["avatar"] : "default-avatar.png");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
    session_unset();
    session_destroy();
    setcookie("username", "", time() - 3600, "/");
    header("Location: index.php");
    exit();
}
//initialize leaderboard if not set yet
if(!isset($_SESSION['leaderboard'])) {
    $_SESSION['leaderboard'] = []; 
}
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $score = intval($_POST['score']);
    $avatar = $_POST['avatar'];
    $_SESSION['leaderboard'][] = [
        'username' => $username,
        'avatar' => $avatar,
        'score' => $score
    ];
    //sort user scores using usort
    usort($_SESSION['leaderboard'], function($player1, $player2) {
        return $player2['score'] - $player1['score'];
    });
    $currentRank = 0;
    $displayRank = 1;
    $prevScore = null;
    foreach($_SESSION['leaderboard'] as $index => &$user) {
        $currentRank++;
        if($prevScore !== $user['score']) {
            $displayRank = $currentRank;
            $user['rank'] = $displayRank;
            $prevScore = $user['score'];
        }
    }
} 
$users = $_SESSION['leaderboard'];  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>Leaderboard</title>
    <style>
        .leaderboard-container {
            width:1000px;
            min-height: 800px;
            overflow: hidden;
            background-color: grey; /* grey background for the games container */
            border-radius: 20px;
            box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.2); /* 5px box shadow */
            justify-content: center;
            text-align: center;
            position: relative;
        }
         /* Leaderboard styling */
         td img {
            width: 36px;
            height: 36px;
            margin-right: .5rem;
            vertical-align: middle;
            box-shadow: 0 .2rem .5rem #0005;
            border-radius: 30px;

        }
        table {
            width: 100%;
        }
        table, th, td {
            padding: 1rem;
            border-collapse: collapse;
            text-align: left;
        }
        .table-header {
            width: 100%;
            max-height: 89%;
            background-color: #fffb;
            padding-left: 5px;
            
        }
        .table-leaderboard {
            width: 90vw;
            height: 90%;
            background-color: #fffb;
            backdrop-filter: blur(7px);
            padding-top: 10px;
            border-radius: 10px;
            margin-top: 100px;
        }
        .table-body {
            width: 100%;
            max-height: calc(89% - .8rem);
            background-color: #fffb;
            margin: .8rem auto;
            border-radius: .6rem;
            overflow: auto;
        }
        .table-body::-webkit-scrollbar{
            width: 0.5rem;
            height: 0.5rem;
        }
        .table-body::-webkit-scrollbar-thumb{
            border-radius: .5rem;
            background-color: #0004;
            visibility: hidden;
        }
        .table-body:hover::-webkit-scrollbar-thumb{
            visibility: visible;
        }
        thead th{
            position: sticky;
            top: 0;
            Left: 0;
            background-color: lightblue;
        }
        tbody tr:nth-child(even){
            background-color: #0000000b;
        }
        tbody tr:hover {
            background-color: #fff6;
        }
    </style>
</head>
<body>
    <header>
        <?php
        $isRegistered = isset($_SESSION["username"]);
        ?>
        <!--navigation bar-->
        <nav class="navbar">
            <div class="navdiv">
                <div class="navdiv left">
                    <ul>
                        <li><a href="index.php" name="home" style="margin-left: -10px;">Home</a></li>
                    </ul>
                </div>
                <div class="navdiv right">
                    <ul>
                        <li><a href="pairs.php" name="memory">Play Pairs</a></li>
                        <?php if ($isRegistered): ?>
                            <li><a href="leaderboard.php">Leaderboard</a></li>
                            <li class="user-menu">
                            <img id="avatarImage" src="<?php echo htmlspecialchars($avatarSrc); ?>" alt="User Avatar">
                                <div class="dropdown-menu">
                                    <div class="dropdown-divider"></div>
                                    <form method="POST" action="" style="display: inline;">
                                        <button type="submit" name="logout" class="dropdown-item" style="border: none; background: none; cursor: pointer;">
                                            Log Out
                                        </button>
                                    </form>
                                </div>
                            </li>
                        <?php else: ?>
                            <li><a href="registration.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        </header>
    <div id="main">
        <div class="leaderboard-container">
            <div class="table-leaderboard">
                <div class="table-header">
                    <h1>Best scores overall</h1>
                </div>
                <div class="table-body">
                    <table>
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>User</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($users as $user): ?>
                                <tr>
                                    <td><strong><?php echo $user['rank']; ?></strong></td>
                                    <td><img src="<?php echo htmlspecialchars($user['avatar']); ?>" alt="Avatar"></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo $user['score']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>