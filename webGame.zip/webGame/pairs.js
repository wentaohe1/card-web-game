//user class to store user data
function User(username, avatar, score) {
    this.username = username;
    this.avatar = avatar;
    this.score = score;
}
let username = sessionStorage.getItem("username");
let avatar = sessionStorage.getItem("selectedAvatar");
let currentUser = new User(username, avatar, 0)
//selects the container where all cards will be displayed
const cardsContainer = document.querySelector(".cards-container");
const cardsContainerTwo = document.querySelector(".cards-container-two");
const cardsContainerThree = document.querySelector(".cards-container-three");
//stores the cards objects
let cards = [];
let firstRoundCards = [];
//keeps track of selected cards
let firstCard, secondCard, thirdCard, fourthCard; 
//prevents clicking more than two, three or four cards at once, depending on the level
let lockBoard = false;
//user score and attempts, round
let score = 0;
let totalScore = 0;
let attempt = 0;
let round = 1;
//card object
let card = {
    skin:null,
    eyes: null,
    mouth: null
}
//an array of emoji skin
let cardSkin = [
    { name: "green", image: "emoji-assets/skin/green.png" },
    { name: "red", image: "emoji-assets/skin/red.png" },
    { name: "yellow", image: "emoji-assets/skin/yellow.png" }
];
//an array of emoji eyes
let cardEyes = [
    { name: "closed eyes", image: "emoji-assets/eyes/closed.png" },
    { name: "laughing eyes", image: "emoji-assets/eyes/laughing.png" },
    { name: "long eyes", image: "emoji-assets/eyes/long.png" },
    { name: "normal eyes", image: "emoji-assets/eyes/normal.png" },
    { name: "rolling eyes", image: "emoji-assets/eyes/rolling.png" },
    { name: "winking eyes", image: "emoji-assets/eyes/winking.png" }
];
//an array of emoji mouth
let cardMouth = [
    { name: "open mouth", image: "emoji-assets/mouth/open.png" },
    { name: "sad mouth", image: "emoji-assets/mouth/sad.png" },
    { name: "smiling mouth", image: "emoji-assets/mouth/smiling.png" },
    { name: "straight mouth", image: "emoji-assets/mouth/straight.png" },
    { name: "surprise mouth", image: "emoji-assets/mouth/surprise.png" },
    { name: "teeth mouth", image: "emoji-assets/mouth/teeth.png" }
];
//timer
let timerInterval;
let elapsedTime = 0;
let totalElapsedTime=0;
function startTimer() {
    elapsedTime=0; //restart the timer
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        elapsedTime++;
        document.getElementById("timer").textContent = elapsedTime;
    }, 1000);
}
function stopTimer() {
    clearInterval(timerInterval);
    return elapsedTime;
}
//this function creates 5 unique cards and stores them in the cards array
function selectEmojiParts(){
    let uniqueCards = [];
    for (let i = 0; i < 5; i++) {
        let card;
        let isDuplicate;
        do {
            isDuplicate = false;
            let randomIndexSkin = Math.floor(Math.random() * 3);
            let randomIndexEyes = Math.floor(Math.random() * 6);
            let randomIndexMouth = Math.floor(Math.random() * 6);
            //create new card object
            card = {
                skin: cardSkin[randomIndexSkin].image,
                eyes: cardEyes[randomIndexEyes].image,
                mouth: cardMouth[randomIndexMouth].image,
                name: cardSkin[randomIndexSkin].name + cardEyes[randomIndexEyes].name + cardMouth[randomIndexMouth].name
            };
            //check for duplicates
            for(let j=0; j < cards.length; j++) {
                if(
                    cards[j].name === card.name
                ) {
                    isDuplicate = true;
                    break;
                }
            }
        } while (isDuplicate); //repeat if the card is duplicate
        uniqueCards.push(card);
    }
    console.log("Selected Emoji Parts:", uniqueCards); //error checking
    return uniqueCards;
}
//this function creates a unique card with given emoji features
function createEmojiCard(card) {
    return new Promise((resolve) => { 
        let canvas = document.createElement("canvas");
        let context = canvas.getContext("2d");

        canvas.width = 200;
        canvas.height = 200;

        //create image objects for each emoji feature
        let skinImg = new Image();
        let eyesImg = new Image();
        let mouthImg = new Image();
        //set the sources for the emoji featuere
        skinImg.src = card.skin;
        eyesImg.src = card.eyes;
        mouthImg.src = card.mouth;
        //keep track of emojies loaded
        let imagesLoaded = 0;

        function checkImagesLoaded() {
            imagesLoaded++;
            if (imagesLoaded === 3) { // Wait until all 3 images are loaded
                context.drawImage(skinImg, 0, 0, 200, 200);
                context.drawImage(eyesImg, 50, 70, 100, 50);
                context.drawImage(mouthImg, 65, 130, 70, 40);
                //convert the canvas drawing into a base64 image URl
                let emojiImageURL = canvas.toDataURL("image/png");
                //resolve the promise
                resolve(emojiImageURL); 
            }
        }
        //when each emoji feature is loaded call checkImagesLoaded to track how many have been loaded
        skinImg.onload = checkImagesLoaded;
        eyesImg.onload = checkImagesLoaded;
        mouthImg.onload = checkImagesLoaded;
    });
}
//function to check win for first round
function checkWinFirst() {
    return new Promise((resolve) => {
        let checkWinFirstInterval = setInterval(() => {
            if (score === 5) {
                console.log("Final elapsed time:", elapsedTime);
                clearInterval(checkWinFirstInterval);
                
                //assign points based on elapsed time
                if (elapsedTime <= 15) {
                    totalScore += 10;
                } else if (elapsedTime <= 20) {
                    totalScore += 2;
                } else if (elapsedTime <= 25) {
                    totalScore += 2;
                }
                
                //assign points based on attempts
                if (attempt <= 5) {
                    totalScore += 10; //perfect attempts
                } else if (attempt <= 10) {
                    totalScore += 5; 
                }
                document.getElementById("attempt").textContent = attempt;
                document.querySelector(".total-score").textContent = totalScore;
                stopTimer();
                startTimer();
                clearBoard();
                resolve(true); //resolves the promise when the condition is met
            }
        }, 500); //check every half a second
    });
}
//function to check win for second round
function checkWinSecond() {
    return new Promise((resolve) => {
        let checkWinSecondInterval = setInterval(() => {
            let flippedCards = countFlippedCards();
            if (flippedCards == 15) {
                console.log("Final elapsed time:", elapsedTime);
                clearInterval(checkWinSecondInterval);
                
                //assign points based on elapsed time
                if (elapsedTime <= 15) {
                    totalScore += 15;
                } else if (elapsedTime <= 20) {
                    totalScore += 10;
                } else if (elapsedTime <= 25) {
                    totalScore += 5;
                }
                
                //assign points based on attempts
                if (attempt <= 5) {
                    totalScore += 10; //perfect attempts
                } else if (attempt <= 10) {
                    totalScore += 5; 
                }
                
                document.getElementById("attempt").textContent = attempt;
                document.querySelector(".total-score").textContent = totalScore;
                stopTimer();
                startTimer();
                clearBoard();
                resolve(true); //resolves the promise when the condition is met
            }
        }, 500); //check every half a second
    });
}
//function to check win for first round
function checkWinThird() {
    return new Promise((resolve) => {
        let checkWinThirdInterval = setInterval(() => {
            let flippedCards = countFlippedCardsTwo();
            console.log("Flipped cards count in round 3:", countFlippedCardsTwo());
            if (flippedCards == 20) {
                console.log("Final elapsed time:", elapsedTime);
                clearInterval(checkWinThirdInterval);
                
                //assign points based on elapsed time
                if (elapsedTime <= 15) {
                    totalScore += 20;
                } else if (elapsedTime <= 25) {
                    totalScore += 15;
                } else if (elapsedTime <= 30) {
                    totalScore += 10;
                }
                
                //assign points based on attempts
                if (attempt <= 5) {
                    totalScore += 30; //perfect attempts
                } else if (attempt <= 10) {
                    totalScore += 20; 
                }
                document.getElementById("attempt").textContent = attempt;
                document.querySelector(".total-score").textContent = totalScore;
                stopTimer();
                clearBoard();
                resolve(true); //resolves the promise when the condition is met
            }
        }, 500); //check every half a second
    });
}
document.querySelector(".score").textContent = score;
document.querySelector(".total-score").textContent = totalScore;
function gameLogic() {
    //first round
    startTimer();
    //hide second and third round containers
    document.querySelector(".cards-container-two").style.display = "none"; 
    document.querySelector(".cards-container-three").style.display = "none";
    document.querySelector(".game-container").style.height =  "600px";
    generateCards(); //generate cards
    //after first round has finished
    checkWinFirst().then((win1) => {
        if(win1) {
            attempt++;
            document.getElementById("attempt").textContent = attempt;
            score = 0;
            document.querySelector(".score").textContent = score;
            //hide first and third round containers
            document.querySelector(".cards-container").style.display = "none"; 
            document.querySelector(".cards-container-three").style.display = "none"; 

            document.querySelector(".game-container").style.height =  "800px";
            //show second round container
            document.querySelector(".cards-container-two").style.display = "grid"; 
            generateCardsTwo();
            checkWinSecond().then((win2) => {
                if(win2) {
                    attempt++;
                    document.getElementById("attempt").textContent = attempt;
                    score = 0;
                    document.querySelector(".score").textContent = score;
                    //hide first and second round containers
                    document.querySelector(".cards-container-two").style.display = "none"; 
                    document.querySelector(".cards-container").style.display = "none"; 
                    //show third round container
                    document.querySelector(".cards-container-three").style.display = "grid";  
                    console.log("Round three started")
                    generateCardsThree();
                    //if game has been won
                    checkWinThird().then((win3) => {
                        if(win3) {
                            gameOver();
                        }
                    })
                }
            })
        }
    });
}
gameLogic();

function shuffleCards() {
    let currentIndex = cards.length,
        randomIndex,
        temporaryValue;
    while(currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -=1;
        temporaryValue = cards[currentIndex];
        cards[currentIndex] = cards[randomIndex];
        cards[randomIndex] = temporaryValue;
    }
}
//generate cards for first round
async function generateCards() {
    let selectedCards = selectEmojiParts();
    firstRoundCards = [...selectedCards]
    cards = [...selectedCards, ...selectedCards];
    shuffleCards(cards); 
    cardsContainer.innerHTML = "";
    for (let card of cards) {
        //generate front card image
        card.image =  await createEmojiCard(card);
        const cardElement = document.createElement("div");
        //create card element
        cardElement.classList.add("card");
        cardElement.setAttribute("data-name", card.name);
        //set inner HTML with selected image
        cardElement.innerHTML = `
            <div class="front">
                <img class="front-image" src=${card.image} />
            </div>
            <div class="back"></div>
        `;
        cardsContainer.appendChild(cardElement);
        cardElement.addEventListener("click", flipCard);
    }
}
//generate cards for second round
async function generateCardsTwo() {
    selectedCards = firstRoundCards;
    cards = [...selectedCards, ...selectedCards, ...selectedCards];
    shuffleCards(cards);  
    cardsContainerTwo.innerHTML = "";
    for (let card of cards) {
        //generate front card image
        card.image =  await createEmojiCard(card);
        const cardElement = document.createElement("div");
        //create card element
        cardElement.classList.add("card-two");
        cardElement.setAttribute("data-name", card.name);
        cardElement.classList.remove("flipped"); //make the cards face-down at the start of the next round
        //set inner HTML with selected image
        cardElement.innerHTML = `
            <div class="front">
                <img class="front-image-two" src=${card.image} />
            </div>
            <div class="back"></div>
        `;
        cardsContainerTwo.appendChild(cardElement);
        cardElement.addEventListener("click", flipCardTwo);
    }
}
//generate cards for third round
//generate cards for second round
async function generateCardsThree() {
    selectedCards = firstRoundCards;
    cards = [...selectedCards, ...selectedCards, ...selectedCards, ...selectedCards];
    shuffleCards(cards);
    cardsContainerThree.innerHTML = "";
    for (let card of cards) {
        //generate front card image
        card.image =  await createEmojiCard(card);
        const cardElement = document.createElement("div");
        //create card element
        cardElement.classList.add("card-three");
        cardElement.setAttribute("data-name", card.name);
        cardElement.classList.remove("flipped"); //make the cards face-down at the start of the next round
        //set inner HTML with selected image
        cardElement.innerHTML = `
            <div class="front">
                <img class="front-image-three" src=${card.image} />
            </div>
            <div class="back"></div>
        `;
        cardsContainerThree.appendChild(cardElement);
        cardElement.addEventListener("click", flipCardThree);
    }
}
function flipCard() {
    if(lockBoard) return; //prevent clicking more cards while checking for a match
    if(this === firstCard) return;

    this.classList.add("flipped");

    if(!firstCard) {
        firstCard = this;
        return;
    }
    secondCard = this;
    document.querySelector(".score").textContent = score;
    document.querySelector(".total-score").textContent = totalScore;
    lockBoard = true;

    checkForMatch();
}
//handle card flipping for three cards
function flipCardTwo() {

    if(lockBoard) return;
    if(this === firstCard || this === secondCard) return;
    this.classList.add("flipped");
    if(!firstCard) {
        firstCard = this;
        return;
    }
    if (!secondCard) {
        secondCard = this;
        return;
    }
    thirdCard = this;
    document.querySelector(".score").textContent = score;
    document.querySelector(".total-score").textContent = totalScore;
    lockBoard = true;

    checkForMatchTwo();
}
//handle card flipping for four cards
function flipCardThree() {
    if(lockBoard) return;
    if(this === firstCard || this === secondCard || this === thirdCard) return;

    this.classList.add("flipped");

    if(!firstCard) {
        firstCard = this;
        return;
    }
    if (!secondCard) {
        secondCard = this;
        return;
    }
    if (!thirdCard) {
        thirdCard = this;
        return;
    }
    fourthCard = this;
    document.querySelector(".score").textContent = score;
    document.querySelector(".total-score").textContent = totalScore;
    lockBoard = true;

    checkForMatchThree();
}
//check match handling for two cards
function checkForMatch() {
    let isMatch = firstCard.dataset.name === secondCard.dataset.name;
    attempt++;
    document.getElementById("attempt").textContent = attempt;
    if (isMatch) {
        disableCards();
        score++;
        totalScore++;
        document.querySelector(".score").textContent = score;
        document.querySelector(".total-score").textContent = totalScore;
    } else {
        unflipCards();
    }
}
//check match handling for three cards
function checkForMatchTwo() {
    let isMatch = firstCard.dataset.name === secondCard.dataset.name && secondCard.dataset.name === thirdCard.dataset.name;
    attempt++;
    document.getElementById("attempt").textContent = attempt;
    if (isMatch) {
        disableCards();
        score++;
        totalScore++;
        document.querySelector(".score").textContent = score;
        document.querySelector(".total-score").textContent = totalScore;
    } else {
        unflipCardsTwo();
    }
}
//check match handling for four cards
function checkForMatchThree() {
    let isMatch = firstCard.dataset.name === secondCard.dataset.name && secondCard.dataset.name === thirdCard.dataset.name && thirdCard.dataset.name === fourthCard.dataset.name;
    attempt++;
    document.getElementById("attempt").textContent = attempt;
    if (isMatch) {
        disableCards();
        score++;
        totalScore++;
        document.querySelector(".score").textContent = score;
        document.querySelector(".total-score").textContent = totalScore;
    } else {
        unflipCardsThree();
    }
}
function disableCards() {
    firstCard.removeEventListener("click", flipCard);
    secondCard.removeEventListener("click", flipCard);

    resetBoard();
}

function unflipCards() {
    setTimeout(() => {
        firstCard.classList.remove("flipped");
        secondCard.classList.remove("flipped");
        resetBoard();
    }, 1000);
}
function unflipCardsTwo() {
    setTimeout(() => {
        firstCard.classList.remove("flipped");
        secondCard.classList.remove("flipped");
        thirdCard.classList.remove("flipped");
        resetBoard();
    }, 1000);
}
function unflipCardsThree() {
    setTimeout(() => {
        firstCard.classList.remove("flipped");
        secondCard.classList.remove("flipped");
        thirdCard.classList.remove("flipped");
        fourthCard.classList.remove("flipped");
        resetBoard();
    }, 1000);
}

function resetBoard() {
    firstCard = null;
    secondCard = null;
    thirdCard = null;
    fourthCard = null;
    lockBoard = false;
}
function resetBoardTwo() {

}

function restart() {
    resetBoard();
    shuffleCards();
    score = 0;
    totalScore = 0;
    attempt = 0;
    round = 1;
    document.getElementById("attempt").textContent = attempt;
    document.querySelector(".score").textContent = score;
    document.querySelector(".total-score").textContent = totalScore;
    document.getElementById("attempt").textContent = attempt;
    cardsContainer.innerHTML = "";
    cardsContainerTwo.innerHTML = "";
    cardsContainerThree.innerHTML = "";
    // Hide rounds 2 and 3
    document.querySelector(".cards-container-two").style.display = "none";
     
    generateCards();
    startTimer();
}

function clearBoard() {
    cardsContainer.innerHTML = ""; 
}
//this function checks the number of flipped cards, if its all the cards on the boards, that means all pairs have been found
function countFlippedCards() {
    let flippedCards = document.querySelectorAll(".card-two.flipped").length;
    return flippedCards;
}
//for counting flipped cards in round 3
function countFlippedCardsTwo() {
    let flippedCards = document.querySelectorAll(".card-three.flipped").length;
    return flippedCards;
}
//this function prints out a game over message
function gameOver() {
    
    document.querySelector(".game-container").innerHTML =
    `
            <div class="game-over">
                <h1>🃏GAME OVER🃏</h1>
                <h2>Total score: ${totalScore}</h2>
                <h2>Time: ${totalElapsedTime}</h2>
                <h2>Attempts: ${attempt}</h2>
                <div class="game-over-buttons">
                    <button onclick="restart()">Restart</button>
                    <button type="submit" onclick="submitScore()" id="submitScoreBtn">Submit</button>
                </div>
            </div>
        `;
        //attach event listener to submit form with fetch
    document.getElementById("submitScoreBtn").addEventListener("click", submitScore);
}
//this functions submits users scores
function submitScore() {
    let formData = new FormData();
    formData.append("username", currentUser.username);
    formData.append("avatar", currentUser.avatar);
    formData.append("score", currentUser.score);
    fetch("leaderboard.php", {
        method:"POST",
        body: formData
    })
    .then(response => response.text()) 
    .then(data => {
        console.log("Score submitted:", data);
        window.location.href = "leaderboard.php"; 
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Failed to submit score.");
    });
}