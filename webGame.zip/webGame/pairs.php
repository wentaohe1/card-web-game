<?php
session_start();
$avatarSrc = isset($_SESSION["avatar"]) ? $_SESSION["avatar"] : (isset($_COOKIE["avatar"]) ? $_COOKIE["avatar"] : "default-avatar.png");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["logout"])) {
    session_unset();
    session_destroy();
    setcookie("username", "", time() - 3600, "/");
    header("Location: index.php");
    exit();
}
//check if start button has been pressed
if (isset($_POST['start_pressed'])) {
    $_SESSION['game_started'] = true;
    header("Location: pairs.php"); // Refresh the page
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script src="pairs.js" defer></script>
    <title>Home</title>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.querySelector('.dropdown-menu');

            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });

            document.addEventListener('click', function() {
                dropdown.classList.remove('show');
            });

            dropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        });
    </script>
    <style>
        .game-container {
            width:1000px;
            min-height: 800px;
            overflow: hidden;
            background-color: grey; /* grey background for the games container */
            border-radius: 20px;
            box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.2); /* 5px box shadow */
            justify-content: center;
            text-align: center;
            position: relative;
        }
        .btn {
            display: inline-block;
            cursor: pointer;
            width:320px;
            height: 100px;
            font-size: 28px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            border-radius:20px;
            background-color: yellow;
            color: black;
            font-weight: bold;
            position: relative;
            top: 50%;
            left: 0%;
        }
        /* ignore this part */
        p {
            display: inline-block;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            top: 50%;
            left: 35%;
        }
        .actions {
            display:flex;
            justify-content:center;
            margin-top: 30px;
            margin-right: 115px;
        }
        .actions p {
            margin: 0 auto;
            font-size:24px;
        }
        .actions button{
            width: 180px;
            height: 55px;
            margin-bottom: 20px;
            border-radius: 20px;
            background-color: #FF9999;

        }
        .cards-container {
            margin-top:170px;
            display: grid;
            justify-content: center;
            grid-template-columns: repeat(5, 140px);
            grid-template-rows: repeat(2, calc(140px/2 * 3));
            grid-gap: 16px;
        }
        .cards-container-two {
            margin-top:150px;
            display: grid;
            justify-content: center;
            grid-template-columns: repeat(5, 110px);
            grid-template-rows: repeat(3, calc(110px/2 * 3));
            column-gap: 16px;
            row-gap: 10px;
        }
        .cards-container-three {
            margin-top:150px;
            display: grid;
            justify-content: center;
            grid-template-columns: repeat(5, 90px);
            grid-template-rows: repeat(4, calc(90px/2 * 3));
            row-gap:4px;
            column-gap:10px;
        }
        .card-three {
            height: calc(80px/2 * 3);
            width: 90px;
            border-radius: 10px;
            position: relative;
            background-color: white;
            transform-style: preserve-3d;
            transition: all 0.5s ease-in-out;
        }
        .card-two {
            height: calc(110px/2 * 3);
            width: 110px;
            border-radius: 10px;
            position: relative;
            background-color: white;
            transform-style: preserve-3d;
            transition: all 0.5s ease-in-out;
        }
        .card {
            height: calc(140px/2 * 3);
            width: 140px;
            border-radius: 10px;
            position: relative;
            background-color: white;
            transform-style: preserve-3d;
            transition: all 0.5s ease-in-out;
        }
        .front-image{
            width:100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }
        .front-image-two{
            width:80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
        }
        .front-image-three{
            width:60px;
            height: 60px;
            object-fit: cover;
            border-radius: 50%;
        }
        .card.flipped, .card-two.flipped, .card-three.flipped{
            transform: rotateY(180deg);
        }
        .front, .back{
            backface-visibility: hidden;
            position:absolute;
            border-radius:10px;
            top: 0px;
            left: 0px;
            height:100%;
            width:100%;
        }
        .card .front{
            display: flex;
            justify-content: center;
            align-items: center;
            transform: rotateY(180deg);
        }
        .card-two .front{
            display: flex;
            justify-content: center;
            align-items: center;
            transform: rotateY(180deg);
        }
        .card-three .front{
            display: flex;
            justify-content: center;
            align-items: center;
            transform: rotateY(180deg);
        }
        .card .back {
            background-image: url("pattern.png");
            background-position: center center;
            background-size: cover;
            backface-visibility: hidden;
        }
        .card-two .back {
            background-image: url("pattern.png");
            background-position: center center;
            background-size: cover;
            backface-visibility: hidden;
        }
        .card-three .back {
            background-image: url("pattern.png");
            background-position: center center;
            background-size: cover;
            backface-visibility: hidden;
        }
        .card .front {
            transform: rotateY(180deg);
        }
        .card-two .front {
            transform: rotateY(180deg);
        }
        .card-three .front {
            transform: rotateY(180deg);
        }
        .timer {
            top: 100px;
            left: 50%;
            transform: translateX(-50%);
            position: absolute;
            padding: 10px 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 10px;
            color: #c0c0c0;

        }

        .score-position {
            margin-left: 110px;
            font-size: 24px;
            background-color: #c0c0c0;
            padding: 10px 20px;
            border-radius: 10px;
        }
        .game-info {
            display:flex;
            flex-direction: column;
        }
        .stats {
            height: 18px;
            display:flex;
            justify-content: space-between;
        }
        .attempt {

        }
        .attempt p{
            margin-left: 115px;
            float: left;
        }
        .round p {
            float: right;
            margin-right:115px;
        }
        .score-button {
            display: flex;
            justify-content: space-between;
        }
        .start {
            margin-top:350px;
            font-size: 72px;
        }
    </style>
</head>
<body>
    <header>
            <?php
            $isRegistered = isset($_SESSION["username"]);
            ?>
            <!--navigation bar-->
            <nav class="navbar">
                <div class="navdiv">
                    <div class="navdiv left">
                        <ul>
                            <li><a href="index.php" name="home" style="margin-left: -10px;">Home</a></li>
                        </ul>
                    </div>
                    <div class="navdiv right">
                        <ul>
                            <li><a href="pairs.php" name="memory">Play Pairs</a></li>
                            <?php if ($isRegistered): ?>
                                <li><a href="leaderboard.php">Leaderboard</a></li>
                                <li class="user-menu">
                                <img id="avatarImage" src="<?php echo htmlspecialchars($avatarSrc); ?>" alt="User Avatar">
                                    <div class="dropdown-menu">
                                        <div class="dropdown-divider"></div>
                                        <form method="POST" action="" style="display: inline;">
                                            <button type="submit" name="logout" class="dropdown-item" style="border: none; background: none; cursor: pointer;">
                                                Log Out
                                            </button>
                                        </form>
                                    </div>
                                </li>
                            <?php else: ?>
                                <li><a href="registration.php">Register</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>
    <div id="main">
        <div class="game-container">
            <?php if(!isset($_SESSION['game_started'])): ?>
                <form method="POST">
                    <div class="start">
                        <h1>🃏PAIRS🃏</h1>
                        <button name="start_pressed" class="btn">START</button>
                    </div>
                </form>
            <?php else: ?>
                <div class="timer">
                    Time: <span id="timer">0</span> sec</div>
                <div class="cards-container">
                </div>
                <div class="cards-container-two">
                </div>
                <div class="cards-container-three">
                </div>
                <div class="game-info">
                    <div class=stats>
                        <div class="attempt"><p>Attempts: <span id="attempt">0</span><p></div>
                        <div class="total-score-position"><p>Total score: <span class="total-score"></span><p></div>
                        <div class="round"><p>Round: <span id="round">1</span><p></div>
                    </div>
                    <div class="score-button">
                        <p class="score-position">Score: <span class="score"></span></p>
                        <div class="actions">
                            <button onclick="restart()"><p>Restart<p></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>