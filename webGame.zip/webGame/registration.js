const tabs = document.querySelectorAll('[data-tab-target]')
const tabContents = document.querySelectorAll('[data-tab-content]')
//make active tabs
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = document.querySelector(tab.dataset.tabTarget)
        tabContents.forEach(tabContent => {
            tabContent.classList.remove('active')
        })
        target.classList.add('active')
        tabs.forEach(tab => {
            tab.classList.remove('active')
        })
        tab.classList.add('active')
        target.classList.add('active')
    })
})

document.addEventListener("DOMContentLoaded", function() {
    const skins = document.querySelectorAll(".skin-option");
    const eyes = document.querySelectorAll(".eyes-option");
    const mouths = document.querySelectorAll(".mouth-option");
    var canvas = document.getElementById('avatar-canvas');
    var context = canvas.getContext('2d');

    //make the first option the default
    const defaultAvatar = {
        skin: "emoji-assets/skin/green.png",
        eyes: "emoji-assets/eyes/normal.png",
        mouth: "emoji-assets/mouth/smiling.png"
    };

    let selectedAvatar = defaultAvatar;
    
    function drawAvatar() {
        context.clearRect(0, 0, canvas.width, canvas.height); // Clear canvas before redrawing

        let skin = new Image();
        let eyes = new Image();
        let mouth = new Image();

        skin.src = selectedAvatar.skin || defaultAvatar.skin;
        eyes.src = selectedAvatar.eyes || defaultAvatar.eyes;
        mouth.src = selectedAvatar.mouth || defaultAvatar.mouth;

        skin.onload = function () {
            context.drawImage(skin, 0, 0, canvas.width, canvas.height);

            eyes.onload = function () {
                context.drawImage(eyes, 0, 0, canvas.width, canvas.height);

                mouth.onload = function () {
                    context.drawImage(mouth, 0, 0, canvas.width, canvas.height);
                };
            };
        };
    }
     //Function to update the selected feature
     function updateFeature(category, newSrc) {
        selectedAvatar[category] = newSrc;
        drawAvatar(); // Redraw avatar after updating
    }
    //skin
    skins.forEach(skin => {
        skin.addEventListener('click', function() {
            skins.forEach(img => img.classList.remove("selected"));
            this.classList.add("selected");
            //save the selected eyes data
            selectedSkin = this.dataset.src;
            updateFeature("skin", selectedSkin);
        });
    });
    //eyes
    mouths.forEach(mouth => {
        mouth.addEventListener('click', function() {
            mouths.forEach(img => img.classList.remove("selected"));
            this.classList.add("selected");
            //save the selected skin's data
            selectedMouth = this.dataset.src;
            updateFeature("mouth", selectedMouth);
        });
    });
    //mouth
    eyes.forEach(eye => {
        eye.addEventListener('click', function() {
            eyes.forEach(img => img.classList.remove("selected"));
            this.classList.add("selected");
            //save the selected mouth data
            selectedEyes = this.dataset.src;
            updateFeature("eyes", selectedEyes);
        });
    });
    drawAvatar();
    //function to save the selected avatar
    function saveAvatar() {
        let avatarImage = canvas.toDataURL("image/png");  // Convert canvas to image

        // Save in localStorage for later retrieval
        localStorage.setItem("selectedAvatar", avatarImage);

        // Save in hidden input field for form submission
        document.getElementById("avatarData").value = avatarImage;

        console.log("Avatar saved:", avatarImage);
    }

    // Ensure avatar is saved when clicking register
    document.querySelector(".btn").addEventListener("click", function() {
        saveAvatar();
    });
});
