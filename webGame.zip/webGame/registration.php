<?php
    session_start();
    //form submission
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = trim($_POST["username"]);
        $avatarData = $_POST["avatarData"];
        $exp = 60 * 60 * 24;
        $error = false;
        if(empty($username)) {
            $error=true;
            echo "Username not set<br>";
        }
        //check for invalid characters
        if(preg_match("/[!@#%&ˆ*()+={}[\]—;:“’<>?/]/", $username)) {
            $error=true;
            echo "Username cannot contain special characters :! @ # % &ˆ* ( ) + = { } [ ] — ; : “ ’ < > ? /";
        } 
        if(!$error){
            //store username and avatar in session and cookies
            $_SESSION["username"] = $username;
            $_SESSION["avatar"] = $avatarData;
            setcookie("username", $username, time() + $exp, "/" );
            setcookie("avatar", $avatarData, time() + $exp, "/" );
            header("Location: index.php");
            exit();
        }
        
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script src="registration.js" defer></script>
    <title>Register</title>
    <style>
        /* registration form styling */
        /* Center the registration form */
        .registration-form {
            width: 500px;
            height: 800px;
            border-radius: 10px;
            padding: 30px 40px;
            border: 2px solid rgba(255, 255, 255, .2);
            background: white;
            color: black;
            text-align: center;
            margin: 50px auto;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            transform: scale(0.8);
        }
        .registration-form h1{
            font-size: 36px;
            text-align: center;
        }
        .registration-form .input-box {
            width: 100%;
            margin-top: 10px;
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .registration-form .input-box input {
            flex: 2; /* Makes input take up twice the space as the label */
            width: 100%;
            height: 20px; 
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        .input-box input::placeholder{
            color: black;
            padding: 0 5px 0 2px;
            font-size: 16px;
        }
        .registration-form .btn{
            width: 100%;
            height: 45px;
            background: black;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0,0,0, .1);
            cursor: pointer;
            font-size: 16px;
            color: #fff;
            font-weight: 600;
        }
        .username-wrapper p, .avatar-builder p{
            float: left;
        }
        /* avatar customization styling*/
        .avatar-preview {
            display: block;
            text-align: center;
            margin-bottom: 10px;
            position: relative;
        }
        .avatar{
            border: 1px solid black;
            height: 250px;
            
        }
        [data-tab-content] {
            display: none;
        }
        /* show the tab when active*/
        .active[data-tab-content] {
            display: block;
        }
        .tabs {
            display: flex;
            justify-content: space-around;
            list-style-type: none;
            background-color: grey;
            padding: 10px;
            margin: 0;
            border-bottom: 1px solid black;
            
            height: 20px;
        }
        .tab {
            cursor:pointer;
            width:180px;
            height:20px;
            border-radius:20px;
            background-color: transparent;
            text-align: center;
            display: flex;  /* Center text inside tabs */
            align-items: center;
            justify-content: center;
            
        }
        .tab.active {
            font-weight: bold;
        }
        .tab-content{
            padding-top:20px;
            padding-bottom: 20px;
        }
        /* styling for skin selection part*/
        .selection {
            display: flex;
            justify-content: space-between;
        }
        .selection img{
            margin-top: 10px;
            width:120px;
            margin-left:10px;
            margin-right: 10px;
        }
        /* styling for eyes and mouth selection part */
        .selection-two{
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            margin: 0 auto;
            width: max-content;
            column-gap: 60px;
        }
        .selection-two img{
            width:80px;
        }
        .skin-option, .eyes-option, .mouth-option {
            cursor: pointer;
            border: 3px solid transparent;
            border-radius: 50%;
            transition: border 0.3s ease-in-out;
        }
        
        .skin-option:hover, .eyes-option:hover, .mouth-option:hover {
            border: 3px solid #aaa; /* Hover effect */
            border-radius: 50%;
        }

        .skin-option.selected, .eyes-option.selected, .mouth-option.selected {
            border: 3px solid red; /* Highlights the selected image */
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <header>
        <?php
        $isRegistered = isset($_SESSION["username"]);
        ?>
        <!--navigation bar-->
        <nav class="navbar">
            <div class="navdiv">
                <div class="navdiv left">
                    <ul>
                        <li><a href="index.php" name="home" style="margin-left: -10px;">Home</a></li>
                    </ul>
                </div>
                <div class="navdiv right">
                    <ul>
                        <li><a href="pairs.php" name="memory">Play Pairs</a></li>
                        <?php if ($isRegistered): ?>
                            <li><a href="leaderboard.php">Leaderboard</a></li>
                        <?php else: ?>
                            <li><a href="registration.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div id="main">
        <!--registration form-->
        <div class="registration-form">
            <form action="" method="POST">
                <h1>🕹️ Register</h1>
                <div class="username-wrapper">
                    <p><strong>Username:</strong></p>
                    <div class="input-box">
                        <input type="text" name="username" placeholder="Please enter your username" required>
                    </div>
                </div>
                <div class="avatar-builder">
                    <p><strong>Create your avatar:</strong></p>
                    <br><br><br><br>
                    <!--avatar preview-->
                    <div class="avatar-preview" id="avatar-div">
                        <canvas id="avatar-canvas" width="300" height="300" style="border:1px solid #000000; border-radius:50%; width:200px;"></canvas>
                    </div>
                    <!--avatar customization-->
                    <div class="avatar">
                        <ul class="tabs">
                            <li data-tab-target="#skin" class="active tab">Skin</li>
                            <li data-tab-target="#eyes" class="tab">Eyes</li>
                            <li data-tab-target="#mouth" class="tab">Mouth</li>
                        </ul>
                        <div class="tab-content">
                            <div  id="skin" data-tab-content class="active">
                                <div class="selection">
                                    <img data-src="emoji-assets/skin/green.png" src="emoji-assets/skin/green.png" alt="green skin" class="skin-option selected" >
                                    <img data-src="emoji-assets/skin/red.png" src="emoji-assets/skin/red.png" alt="red skin" class="skin-option">
                                    <img data-src="emoji-assets/skin/yellow.png" src="emoji-assets/skin/yellow.png" alt="yellow skin" class="skin-option">
                                </div>
                            </div>
                            <div  id="eyes" data-tab-content >
                                <div class="selection-two">
                                    <img data-src="emoji-assets/eyes/normal.png" src="emoji-assets/eyes/normal.png" alt="normal Eyes" data-value="normal" class="eyes-option selected">
                                    <img data-src="emoji-assets/eyes/laughing.png"src="emoji-assets/eyes/laughing.png" alt="laughing Eyes" data-value="laughing" class="eyes-option">
                                    <img data-src="emoji-assets/eyes/long.png" src="emoji-assets/eyes/long.png" alt="long Eyes" data-value="long" class="eyes-option">
                                    <img data-src="emoji-assets/eyes/closed.png" src="emoji-assets/eyes/closed.png" alt="closed Eyes" data-value="closed" class="eyes-option">
                                    <img data-src="emoji-assets/eyes/rolling.png" src="emoji-assets/eyes/rolling.png" alt="rolling Eyes" data-value="rolling" class="eyes-option">
                                    <img data-src="emoji-assets/eyes/winking.png" src="emoji-assets/eyes/winking.png" alt="winking Eyes" data-value="winking" class="eyes-option">
                                </div>
                            </div>
                            <div  id="mouth" data-tab-content >
                                <div class="selection-two">
                                    <img data-src="emoji-assets/mouth/smiling.png"src="emoji-assets/mouth/smiling.png" alt="smiling mouth" class="mouth-option selected">
                                    <img data-src="emoji-assets/mouth/sad.png"src="emoji-assets/mouth/sad.png" alt="sad mouth" class="mouth-option">
                                    <img data-src="emoji-assets/mouth/open.png"src="emoji-assets/mouth/open.png" alt="open mouth" class="mouth-option">
                                    <img data-src="emoji-assets/mouth/straight.png"src="emoji-assets/mouth/straight.png" alt="straight mouth" class="mouth-option">
                                    <img data-src="emoji-assets/mouth/surprise.png"src="emoji-assets/mouth/surprise.png" alt="surprise mouth" class="mouth-option">
                                    <img data-src="emoji-assets/mouth/teeth.png"src="emoji-assets/mouth/teeth.png" alt="teeth mouth" class="mouth-option">
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
                <input type="hidden" name="avatarData" id="avatarData">
                <button type="submit" class="btn" onclick="saveAvatar()" style="margin-top: 20px">Register</button>
            </form>
        </div>
    </div>
</body>
</html>
